package com.example.demo.dao;

import org.springframework.stereotype.Component;
@Component
public class ClienteDAO {
    public void insertarCliente(){
        System.out.println("Trabajo realizado antes");
    }
}
